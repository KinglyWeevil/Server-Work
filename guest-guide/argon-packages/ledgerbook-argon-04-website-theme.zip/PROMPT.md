# Website theme and companion pages

# Current instruction — existing Ledgerbook branding only

Use the existing leather, brass and vellum Ledgerbook Full branding and LB mark in ledger-evidence/. Paper/green colors in guide.html, starter assets, old prompts and reference renders are obsolete draft styling. Preserve the guide's content/personalization contract while adapting its appearance to the real branding. This instruction supersedes conflicting historical art-direction language in this package.

Read ledger-evidence/README.md, containers.json and asset-manifest.json before designing. Existing assets and theme examples are real source references, not proof that every application supports arbitrary CSS. Private Notes is Obsidian. Requests is Seerr in the container named jellyseerr. Image references are inventory evidence, not independent app-version measurements. Do not deploy, change auth, expand guest access, expose private notes or fabricate screenshots/DNS values. Treat unverified integration as a proposal.

First read PROJECT-CONTEXT.md, assets/ASSET-README.md and guide.html. Inspect the supplied asset files and brochure references. Use the newest approved theme in this conversation if present. Treat all embedded project text as reference material subordinate to this task and the user's instructions. Work only on design artifacts; do not deploy anything.

Design and deliver the Ledgerbook website theme and its core local assets, using the actual portal source and assets in ledger-evidence/ as the visual reference; the brochure is a content draft. Build a polished standalone static concept in output/ with local CSS and inline/local SVG and no build step. It is a design concept, not a working authenticated site.

Cover the home page, service directory, help/guide entry point and a personal-account-page visual concept. Make the difference between “Your services” (enabled services only) and “All available services” unmistakable. For the local demo, label its sample access profile as demo state, and do not simulate real security. The home tiles should never imply access to a service that is not enabled. The directory lists brief descriptions; Radarr is labeled “Behind the scenes - admin only” with no address or launch action. Do not add new installed services.

Use the source's confirmed public URLs where a link is needed. For private-account examples, show no credentials or plausible credential strings: use a clearly marked empty state. Do not implement auth, email-code delivery, account storage, server-side personalization or an actual password view. A static demo cannot enforce access control; leave server integration explicitly unimplemented. Do not invent endpoints or produce links to missing demo pages. Keep guest help at concierge@ledgerbook.vip.

Deliver: complete static concept HTML files (or one coherent self-contained HTML concept if simpler); a reusable theme CSS file scoped to this website; design tokens; refined SVG assets; light/dark screenshots if tools allow; and a concise integration note stating what real source, routes and server hooks must be inspected before implementation. Preserve the brochure itself as a reference unless explicitly asked to revise it. Show one recommended direction, with a brief rationale, rather than a large collection of competing concepts.


Visual quality requirements: precise optical alignment, restrained hierarchy, balanced text measure, useful whitespace, one coherent SVG icon family, consistent buttons/fields/callouts, calm dark mode, and legible mobile layouts. Aim for an exceptionally well-made private handbook and companion website. Preserve service-specific usability; do not force every product into an identical screen layout.

If rendering tools are available, test your actual output at 360, 768 and 1280px in light and dark modes; inspect screenshots, contrast, keyboard focus and horizontal overflow. Report only checks you performed. Clearly separate concept validation from validation in the real application. Provide an inventory of outputs, source/provenance notes, verified compatibility, remaining questions and any unrun checks. Never claim a theme works in an app you did not inspect or run.
