# Ledgerbook handoff context

## Established direction
Warm paper, dark ink, forest-green accent; serif display type, system sans-serif instructions, fine ledger rules. Familiar, welcoming, carefully typeset, practical for family and friends using phones. Evolve the identity consistently across the website and services. Avoid a crowded dashboard, gradients, glass effects, excessive panels, and decorative motion.

## Sources and limitations
The included guide.html is the factual baseline. Assets in assets/ are an extracted brochure reference plus newly authored SVG starter icons, identified in ASSET-README.md. Reference renders show the brochure, not any running website or container. No website source, actual application screenshots, container definitions, image tags, versions, UI themes or deployment configuration were supplied. Package labels describe intended design targets, NOT proof of deployed containers. Do not infer deployment details from a product name.

## Latest user decisions
- A guest's home page shows only the service tiles they can use. The complete all-services directory remains visible independently. Unavailable member services get descriptions, not misleading launch actions. Links for discovery go to that directory.
- Radarr is approved as a directory name/description labeled “Behind the scenes - admin only.” Do not expose admin URLs, create guest setup instructions for it, or add unconfirmed products to the inventory.
- All guest support goes to mailto:concierge@ledgerbook.vip.
- The personalized Minecraft section retains minecraft.ledgerbook.vip, Java port 25565, Bedrock port 19132, and the requirement to enter required DNS settings for every distinct Wi-Fi network. Exact DNS values, device steps and the prior Minecraft brochure are still missing. Never guess DNS values or fake console screenshots.
- Preserve every [[FILL: ...]] factual placeholder unless the user supplies the answer. Starter credentials belong only on the personalized setup page, never in assets, examples, documentation, screenshots or source.

## Technical boundaries
No remote fonts, CDNs, trackers or third-party asset fetches. Use system fonts, local assets or inline SVG; maintain light/dark modes, WCAG AA text contrast, keyboard focus, reduced motion and phone layouts at 360/768/1280px. Do not build or deploy infrastructure, modify authentication, permissions, routes, accounts, containers, firewall rules or live data as part of a design task.

A third-party application's supported customization surface must be verified for its actual edition/version before proposing installable overrides. Preserve vendor navigation and core interaction behavior. Never invent CSS selectors, theme APIs, file mounts or environment variables and call them verified. If source/version evidence is missing, provide an explicit design proposal or standalone local concept labeled as such; separate verified artifacts from proposed integration. Do not ask for credential values or dump secrets. Do not submit an entire unknown deployment config or environment dump as design evidence.

## Cross-stage handoff
If the conversation includes newer approved brand assets or a revised guide, use those instead of the baseline here and state which version was used. These ZIPs cannot include future design outputs. Each is self-contained, but keeping work in the same Argon conversation preserves approved decisions. Preserve baseline files and put new deliverables in output/.
