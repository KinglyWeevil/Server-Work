# Ledgerbook complete design suite

Read this file first. This ZIP contains independent task folders, each with PROMPT.md, guide.html, project context and relevant assets. Do not treat every prompt as a simultaneous instruction.

Existing leather/brass/vellum branding is authoritative; paper/green draft styling is obsolete. Shared actual evidence is at the root ledger-evidence/ folder, referenced by all task folders.

Recommended default: begin with 05-shared-asset-kit/PROMPT.md, develop one reviewable shared visual direction, and pause for feedback before a full site or individual-app implementation. Then apply approved assets to 04-website-theme. Complete the brochure stages or one selected app task at a time using the newest approved outputs in this conversation. If the user names a target, go directly to that folder's PROMPT.md.

App folder names identify intended visual-design targets, not verified deployed containers. Read ledger-evidence/README.md for the actual inventory, portal source subset, branding assets and verification limits. Existing leather/brass/vellum branding overrides obsolete paper/green draft styling. Read each context file's limitations. Never assume theme support, apply changes to live services, invent DNS values or fabricate device screenshots.

## Task folders

- 01-art-direction/PROMPT.md
- 02-design-and-icons/PROMPT.md
- 03-final-audit/PROMPT.md
- 04-website-theme/PROMPT.md
- 05-shared-asset-kit/PROMPT.md
- 06-seerr/PROMPT.md
- 07-audiobookshelf/PROMPT.md
- 08-kavita/PROMPT.md
- 09-calibre-web/PROMPT.md
- 10-jellyfin/PROMPT.md
- 11-radarr-admin/PROMPT.md
- 12-private-notes/PROMPT.md
- 13-minecraft-companion/PROMPT.md
- 14-plex-companion/PROMPT.md
