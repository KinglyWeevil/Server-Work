# Current instruction — existing Ledgerbook branding only

Use the existing leather, brass and vellum Ledgerbook Full branding and LB mark in ledger-evidence/. Paper/green colors in guide.html, starter assets, old prompts and reference renders are obsolete draft styling. Preserve the guide's content/personalization contract while adapting its appearance to the real branding. This instruction supersedes conflicting historical art-direction language in this package.

Read ledger-evidence/README.md, containers.json and asset-manifest.json before designing. Existing assets and theme examples are real source references, not proof that every application supports arbitrary CSS. Private Notes is Obsidian. Requests is Seerr in the container named jellyseerr. Image references are inventory evidence, not independent app-version measurements. Do not deploy, change auth, expand guest access, expose private notes or fabricate screenshots/DNS values. Treat unverified integration as a proposal.

# Current project context

The included guide.html is the current working baseline. Use existing Ledgerbook leather, brass and vellum branding from ledger-evidence/. Paper/green styling is obsolete. This is a private guest handbook, primarily read on phones, with an offline self-contained HTML deliverable and US-letter print support.

Latest user decisions supersede older briefs:
- Direct service discovery to the all-services directory, not to a support request when a guest cannot open something. The home page should show only a guest's enabled tiles.
- Keep the full directory visible independently of enabled-service instructions. Radarr is explicitly approved as a name/description-only directory entry labeled “Behind the scenes - admin only.” Do not invent additional installed services.
- Include minecraft.ledgerbook.vip, Java port 25565, and Bedrock port 19132 inside the personalized Minecraft section. Explain that required Bedrock DNS settings must be entered for each distinct Wi-Fi network.
- Exact DNS values, device-specific steps, and the earlier Minecraft brochure are not available in this package. Retain placeholders. Authentic device screenshots were requested, but none have been supplied or verified. The included phone preview is a render of this brochure, NOT a device setup screenshot.
- Concierge email is the single contact: concierge@ledgerbook.vip. Do not include credential values.

Asset roles:
- guide.html: editable baseline and source of factual copy, links and personalization hooks.
- references/phone-preview.png: baseline first-screen phone render, not a full-page review or an aspirational design.
- references/guide-print-check.pdf: baseline print render, not a polished final PDF. Its full-source version is 22 pages; improve awkward pagination where possible without cutting content.
- references/review-notes.md: unresolved placeholders and current limitations.
- references/checks.json: checks run on the included baseline. These results do not validate any subsequent revision. Browser checks measured geometry, palette contrast, print content, and personalization; they were not a complete visual or assistive-technology audit.

Do not treat historical checks as new evidence. Do not fill unresolved facts from guesses. Prefer a newer user-approved guide or design supplied in the conversation over this baseline when continuing stages 2 or 3. Keep the original baseline recoverable.
