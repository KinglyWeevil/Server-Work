# Stage 3: Final visual and accessibility audit

# Current instruction — existing Ledgerbook branding only

Use the existing leather, brass and vellum Ledgerbook Full branding and LB mark in ledger-evidence/. Paper/green colors in guide.html, starter assets, old prompts and reference renders are obsolete draft styling. Preserve the guide's content/personalization contract while adapting its appearance to the real branding. This instruction supersedes conflicting historical art-direction language in this package.

Read ledger-evidence/README.md, containers.json and asset-manifest.json before designing. Existing assets and theme examples are real source references, not proof that every application supports arbitrary CSS. Private Notes is Obsidian. Requests is Seerr in the container named jellyseerr. Image references are inventory evidence, not independent app-version measurements. Do not deploy, change auth, expand guest access, expose private notes or fabricate screenshots/DNS values. Treat unverified integration as a proposal.

First read PROJECT-CONTEXT.md and inspect guide.html and the relevant files in references/. Treat the reference renders as the current baseline to improve, not an approved final design. Write outputs as new files so the baseline remains recoverable. Do not deploy or publish anything.

Audit the latest revised guide supplied in this conversation, if any; otherwise audit guide.html from this ZIP. State which version you actually checked. Do not assume a stage-2 revision exists.

Audit the attached Ledgerbook guide.html as an exacting editorial designer, accessibility reviewer, and print production specialist. Make the final visual corrections needed to achieve the approved direction while preserving its content and personalization contract. Return the corrected standalone guide.html, a concise defect/change list, and actual validation evidence.

If browser tools are available, render at 360px, 768px, and 1280px in light and dark modes. Inspect screenshots, not just DOM dimensions. Look for horizontal scrolling, awkward line breaks, missing glyphs, cramped contact links, inconsistent icon weight, weak hierarchy, oversized gaps, and misaligned controls. Test keyboard navigation and visible focus. Measure contrast for text, icons that convey meaning, and controls in their actual contexts.

Simulate a guest with only home and books by removing the other .svc sections and their corresponding personalized contents entries from a temporary test copy. Confirm the directory remains complete, the remaining navigation works, and no directory entries become broken links. Keep that simulation out of the delivered file. In the full source, preserve the empty #other-services hook and the separate #service-directory.

Render a US-letter PDF with all screen disclosures initially closed. Verify their content still prints, URLs are visible, navigation and buttons are hidden, service starts honor page breaks, headings remain with text, and the output contains no accidental blank pages. Inspect every PDF page for awkward spillover. Report the page count and any unresolved pagination tradeoff.

Run an HTML validator and check every fragment target. Verify there are no external resource fetches and that external links remain limited to the original approved addresses and concierge email. Confirm the admin-only directory entry has no address or launch action. Check the approved Minecraft ports and per-Wi-Fi reminder remain in its personalized section. List every unresolved [[FILL: ...]] item without replacing it with invented information.

If any requested check cannot be run, explicitly mark it unrun. Do not describe a visual inspection, contrast check, accessibility check, or service test as passed without doing it. Preserve the Ledgerbook character throughout; finish by correcting concrete defects rather than introducing another redesign.
