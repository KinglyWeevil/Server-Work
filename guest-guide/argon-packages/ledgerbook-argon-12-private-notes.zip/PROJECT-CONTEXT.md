# Current instruction — existing Ledgerbook branding only

Use the existing leather, brass and vellum Ledgerbook Full branding and LB mark in ledger-evidence/. Paper/green colors in guide.html, starter assets, old prompts and reference renders are obsolete draft styling. Preserve the guide's content/personalization contract while adapting its appearance to the real branding. This instruction supersedes conflicting historical art-direction language in this package.

Read ledger-evidence/README.md, containers.json and asset-manifest.json before designing. Existing assets and theme examples are real source references, not proof that every application supports arbitrary CSS. Private Notes is Obsidian. Requests is Seerr in the container named jellyseerr. Image references are inventory evidence, not independent app-version measurements. Do not deploy, change auth, expand guest access, expose private notes or fabricate screenshots/DNS values. Treat unverified integration as a proposal.

# Ledgerbook handoff context

## Established direction
Existing dark leather, brass and vellum, approved LB mark, serif headings and native readable controls. Paper/green draft styling is obsolete. Familiar, welcoming, carefully typeset, practical for family and friends using phones. Evolve the identity consistently across the website and services. Avoid a crowded dashboard, gradients, glass effects, excessive panels, and decorative motion.

## Sources and limitations
The included guide.html is the factual baseline. Assets in assets/ are an extracted brochure reference plus newly authored SVG starter icons, identified in ASSET-README.md. Reference renders show the brochure, not any running website or container. See ledger-evidence/README.md for actual image references, source subset and existing theme surfaces. No authenticated screenshots or deployment configuration are included. Do not infer deployment details from a product name.

## Latest user decisions
- A guest's home page shows only the service tiles they can use. The complete all-services directory remains visible independently. Unavailable member services get descriptions, not misleading launch actions. Links for discovery go to that directory.
- Radarr is approved as a directory name/description labeled “Behind the scenes - admin only.” Do not expose admin URLs, create guest setup instructions for it, or add unconfirmed products to the inventory.
- All guest support goes to mailto:concierge@ledgerbook.vip.
- The personalized Minecraft section retains minecraft.ledgerbook.vip, Java port 25565, Bedrock port 19132, and the requirement to enter required DNS settings for every distinct Wi-Fi network. Exact DNS values, device steps and the prior Minecraft brochure are still missing. Never guess DNS values or fake console screenshots.
- Preserve every [[FILL: ...]] factual placeholder unless the user supplies the answer. Starter credentials belong only on the personalized setup page, never in assets, examples, documentation, screenshots or source.

## Technical boundaries
No remote fonts, CDNs, trackers or third-party asset fetches. Use system fonts, local assets or inline SVG; maintain light/dark modes, WCAG AA text contrast, keyboard focus, reduced motion and phone layouts at 360/768/1280px. Do not build or deploy infrastructure, modify authentication, permissions, routes, accounts, containers, firewall rules or live data as part of a design task.

A third-party application's supported customization surface must be verified for its actual edition/version before proposing installable overrides. Preserve vendor navigation and core interaction behavior. Never invent CSS selectors, theme APIs, file mounts or environment variables and call them verified. If source/version evidence is missing, provide an explicit design proposal or standalone local concept labeled as such; separate verified artifacts from proposed integration. Do not ask for credential values or dump secrets. Do not submit an entire unknown deployment config or environment dump as design evidence.

## Cross-stage handoff
If the conversation includes newer approved brand assets or a revised guide, use those instead of the baseline here and state which version was used. These ZIPs cannot include future design outputs. Each is self-contained, but keeping work in the same Argon conversation preserves approved decisions. Preserve baseline files and put new deliverables in output/.
