# Stage 1: Art direction — review before implementation

# Current instruction — existing Ledgerbook branding only

Use the existing leather, brass and vellum Ledgerbook Full branding and LB mark in ledger-evidence/. Paper/green colors in guide.html, starter assets, old prompts and reference renders are obsolete draft styling. Preserve the guide's content/personalization contract while adapting its appearance to the real branding. This instruction supersedes conflicting historical art-direction language in this package.

Read ledger-evidence/README.md, containers.json and asset-manifest.json before designing. Existing assets and theme examples are real source references, not proof that every application supports arbitrary CSS. Private Notes is Obsidian. Requests is Seerr in the container named jellyseerr. Image references are inventory evidence, not independent app-version measurements. Do not deploy, change auth, expand guest access, expose private notes or fabricate screenshots/DNS values. Treat unverified integration as a proposal.

First read PROJECT-CONTEXT.md and inspect guide.html and the relevant files in references/. Treat the reference renders as the current baseline to improve, not an approved final design. Write outputs as new files so the baseline remains recoverable. Do not deploy or publish anything.

You are the art director for Ledgerbook, a private guest guide for Michael’s family and friends. Study the attached guide.html before proposing changes. Evolve its existing identity into a carefully crafted editorial design: warm paper, dark ink, restrained forest green, serif display headings, system sans-serif instructions, fine ledger rules, and generous but purposeful spacing. Preserve its familiar, welcoming character.

The audience is nontechnical and reads primarily on phones. The aesthetic should feel like an exceptionally well-typeset personal handbook. Aim for quiet confidence, precise alignment, balanced typography, and clear information hierarchy. Avoid dashboard styling, oversized empty hero areas, gradients, glass effects, excessive cards, decorative animations, and visual clutter. Decoration must earn its place.

Show ONE recommended direction and one restrained alternative. For each, provide a compact art-direction board with specific color tokens, system font stacks, type scale, spacing scale, line weights, button treatment, section markers, and icon style. Demonstrate the cover, contents, one service heading, one step list, a help callout, and a directory entry. Describe the corresponding dark and print treatments.

Treat the current copy and service inventory as authoritative. Preserve the distinction between a guest’s enabled services and the all-services directory. Radarr is a directory-only entry labeled “Behind the scenes - admin only,” without an address or action button. Do not add other products or claim they are installed.

Keep this stage to a reviewable design proposal. Do not rewrite the full file yet. Explicitly identify the decisions you want me to approve before implementation. State any tool limitations; do not imply you rendered mockups if you only described them.
