# Stage 2: Implement the approved design and bespoke icon system

First read PROJECT-CONTEXT.md and inspect guide.html and the relevant files in references/. Treat the reference renders as the current baseline to improve, not an approved final design. Write outputs as new files so the baseline remains recoverable. Do not deploy or publish anything.

If the conversation contains an approved stage-1 design or a newer guide, apply that. If this ZIP is your only context, refine the included theme as the approved starting point; do not claim to have seen or followed a separate stage-1 approval.

Apply the approved Ledgerbook art direction to the attached guide.html. Return a complete, self-contained guide.html and a brief explanation of the visual changes. Preserve its factual copy, useful instructions, existing URLs, placeholder text, service order, and personalization hooks. Improve visual execution through typography, composition, spacing, iconography, and interaction details.

Craft a coherent family of small inline SVG icons for home, movies/shows, requests, audiobooks/podcasts, ebooks/comics, ebook shelves, Minecraft, private notes, and the directory. Use one consistent grid (such as 24 × 24), stroke weight, corner treatment, optical weight, and alignment. Make each silhouette recognizable at 20–24 CSS pixels. Use currentColor, no external assets, and appropriate decorative accessibility attributes when a text label already supplies the meaning. Avoid brand logos and avoid mixing emoji, Unicode symbols, filled icons, and outline icons. Let Radarr’s directory entry use the same restrained visual language with a clear text label indicating its admin-only role. Retain readable labels; icons must never carry meaning alone.

Refine heading measure, line height, paragraph rhythm, numbered steps, callout padding, divider placement, focus rings, tap targets, disclosure indicators, and URL wrapping. Keep the guide easy to scan at 360px and comfortable at 768px and 1280px. Use a single reading column. Keep navigation convenient without a tall sticky element obscuring content. Keep the service directory legible as a compact editorial list; do not make unavailable services look like launch buttons. All services must remain findable from the contents.

Non-negotiable implementation constraints:
- One HTML file, inline CSS and inline SVG, no build step, no fetched fonts, CSS, scripts, images, analytics, or libraries. All styling and icons must render offline.
- System font stacks only. Light/dark mode via prefers-color-scheme. At least 4.5:1 contrast for normal text, visible keyboard focus, semantic heading order, lang="en", and comfortable tap targets.
- Preserve each <section class="svc" data-service="KEY" data-summary="..."> and its ID. Keys: home, plex, requests, audio, books, library, minecraft, notes. Preserve corresponding data-service attributes on personalized contents entries.
- Preserve the empty <section id="other-services"></section> immediately after the service sections. Keep the populated #service-directory separate. Its entries must remain visible when enabled-service sections and their contents links are removed. Do not give directory entries data-service attributes, link them to potentially removed sections, or add client-side permission logic.
- Admin-only tools get names, brief descriptions, and their admin-only labels in the directory; no addresses, credentials, configuration instructions, or access buttons. Radarr is the only admin-only tool currently confirmed for this directory.
- US-letter print: hide contents and buttons, show useful addresses as text, reveal every disclosure’s contents even if closed on screen, start each enabled service on a fresh page, and avoid stranded headings or wasteful near-empty pages. Make visual rules work in grayscale. Do not shrink body text below a comfortable print size to force pagination.
- No JavaScript unless strictly necessary for expanding/collapsing disclosures, and then fewer than 30 lines. Never implement personalization in the page.
- All contact links go to mailto:concierge@ledgerbook.vip. Never insert credentials or invent missing facts.
- The Minecraft section must retain minecraft.ledgerbook.vip, Java port 25565, Bedrock port 19132, and the reminder that required DNS settings must be entered for every different Wi-Fi network. Keep its unknown DNS values and device steps as placeholders. Never fabricate device screenshots or present generated pictures as actual console UI.

Do not silently resolve content placeholders, remove useful troubleshooting steps, or claim live services were tested. Finish with a short list of preserved constraints, remaining placeholders, and any limitations you actually encountered.
